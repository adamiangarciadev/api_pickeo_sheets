# API Pickeo con Guardado en Google Drive

Sube archivos .txt con códigos a una carpeta específica de Drive.